import { Component } from '@angular/core';

@Component({
  selector: 'cmp-finances',
  templateUrl: 'finances.html',
  
})
export class FinancesComponent {

  constructor() { }

}