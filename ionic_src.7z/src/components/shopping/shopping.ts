import { Component } from '@angular/core';

import { AlertController } from 'ionic-angular';
// import { Events } from 'ionic-angular';

@Component({
  selector: 'cmp-shopping',
  templateUrl: 'shopping.html',
  
})
export class ShoppingComponent {

  constructor() {
    // constructor(private alertCtrl: AlertController, public events: Events) {
  }


}
