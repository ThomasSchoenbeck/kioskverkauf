import { Component } from '@angular/core';

@Component({
  selector: 'cmp-actions',
  templateUrl: 'actions.html'
})
export class ActionsComponent {

  constructor() {
  }

}
