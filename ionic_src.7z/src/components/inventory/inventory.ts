import { Component } from '@angular/core';

@Component({
  selector: 'cmp-inventory',
  templateUrl: 'inventory.html',
  
})
export class InventoryComponent {

  constructor() { }

}