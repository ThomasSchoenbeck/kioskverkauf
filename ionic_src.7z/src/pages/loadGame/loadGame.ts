import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-loadGame',
  templateUrl: 'loadGame.html'
})
export class LoadGamePage {

  constructor(public navCtrl: NavController) {

  }

}
