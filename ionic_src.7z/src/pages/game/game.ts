import { Component, ViewChild } from '@angular/core';

import { NavController, Events, Content, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-game',
  templateUrl: 'game.html'
})
export class GamePage {

  @ViewChild(Content) content: Content;

  private selectedCity: string;
  private gameStarted: boolean = false;
  private shopping: boolean = false;

  private gameTabs: string = "inventory";

  constructor(public navCtrl: NavController, public events: Events, private navParams: NavParams) {
    this.selectedCity = navParams.get('selectedCity');
  }

}