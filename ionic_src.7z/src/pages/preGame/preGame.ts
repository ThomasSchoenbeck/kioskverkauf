import { Component, ViewChild } from '@angular/core';

import { NavController, Events, Content } from 'ionic-angular';

import { GamePage } from '../game/game';

@Component({
  selector: 'page-preGame',
  templateUrl: 'preGame.html'
})
export class PreGamePage {

  @ViewChild(Content) content: Content;

  private selectedCity: string;
  private gameStarted: boolean = false;

  constructor(public navCtrl: NavController, public events: Events) {

    this.events.subscribe('city:selected', (eventData) => {
    // userEventData is an array of parameters, so grab our first and only arg
      console.log(`GamePage: City has been selected!`);
      this.selectedCity = eventData[0];
    });

    this.events.subscribe('shop:selected', (eventData) => {
      console.log(`GamePage: Game has been started!`);
      this.navCtrl.push(GamePage, { //http://www.joshmorony.com/a-simple-guide-to-navigation-in-ionic-2/
        selectedCity: this.selectedCity
      }).then(() => {
        this.navCtrl.pop();
      });

      // this.gameStarted = !this.gameStarted;
      // this.content.resize();
    });

  }

  // setSelectedCity(city) {
  //   this.selectedCity = city;
  // }

}